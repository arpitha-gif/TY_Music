import React from 'react'
import {useHistory} from 'react-router-dom'

function Contact(props) {
       const history = useHistory()
     console.log('Contact page props',props);
     const navigateToHome = ()=>{
         history.push('/home')
     }
  return (
    <div>
        Contact Page
        <button onClick={navigateToHome}>Navigate to home</button>
    </div>
  )
}

export default Contact