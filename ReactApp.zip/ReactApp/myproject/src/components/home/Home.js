import React from 'react'
import './Home.css'

function Home(props) {
    console.log('Home:',props);
    
    const navigateToAbout = (props)=>{
        //navigating programatically
        props.history.push('/about')
    }
  return (
    <div className='textcolor'>
        Home Page
        <button onClick={navigateToAbout}>Navigate to About page</button>
    </div>
  )
}

export default Home