import React from 'react'
import './About.css'

function About() {
  return (
    <div className='textcolor'>
        About Page
    </div>
  )
}

export default About