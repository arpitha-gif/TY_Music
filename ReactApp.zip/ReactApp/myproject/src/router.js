import {BrowserRouter as Router, Route, Link} from 'react-router-dom';
import About from "./components/about/About";
import Home from './components/home/Home';
import Contact from './components/contact/Contact';

const routing = (
    <Router>
        <div>
            <div>
                <Link to="/">About</Link>
            </div>
            <div>
                <Link to="/home">Home</Link>
            </div>
            <Route exact path ="/" component={About}/>
            <Route path="/home" component={Home}/>
            <Route path="/contact" component={Contact}/>
        </div>
    </Router>
)

export default routing