import React from "react";

function DashBoard() {
  return <div>Dashboard</div>;
}

export default DashBoard;
